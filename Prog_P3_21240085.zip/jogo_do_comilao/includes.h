#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#define nome_fich "jogo_anterior.dat"
#define nome_fich_txt "jogo_anterior.txt"
#include "estruturas.h"
#include "tabuleiro.h"
#include "ficheiros.h"
#include "jogada.h"
