guardar_tabuleiro_inicial(QUADRADO *tabuleiro);
void guardar_sucessao(QUADRADO *tabuleiro, JOGADA *jog);
int indicar_modo_de_jogo_anterior();
